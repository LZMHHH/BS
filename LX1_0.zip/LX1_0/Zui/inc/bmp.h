/**
  ******************************************************************************
  * @file    BMP.c
  * @author  lss
  * @version V1.0
  * @date    2020-xx-xx
  * @brief   .
  ******************************************************************************
  * @attention
  *
  * ʵ��ƽ̨:STʵ����-LZM
  * 
  * Wechat��qabc132321
  *
  ******************************************************************************
  */
#ifndef __BMP_H
#define __BMP_H

extern const unsigned char UI_NOSIGNAL8X8[8];
extern const unsigned char UI_ASIGNAL8X8[8];

#endif
