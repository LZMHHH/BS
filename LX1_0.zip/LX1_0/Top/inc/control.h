/**
  ******************************************************************************
  * @file    control.h
  * @author  fire
  * @version V1.0
  * @date    2017-xx-xx
  * @brief   
  ******************************************************************************
  * @attention
  *
  * ʵ��ƽ̨:˫��ʵ����-LZM
  * 
  * Wechat��qabc132321
  *
  ******************************************************************************
  */
#ifndef __CONTROL_H
#define __CONTROL_H

#include "includes.h"

long map(long x, long in_min, long in_max, long out_min, long out_max);


#endif
