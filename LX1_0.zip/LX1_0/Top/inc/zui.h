#ifndef __SHOW_H
#define __SHOW_H
#include "sys.h"


/* ״̬���� */
typedef enum
{
    SHOW_Close,          /*  */
    SHOW_Load,      /*  */
    SHOW_Date,       /* */
}SHOW_Status;



void Main_ZUI(void);


#endif
